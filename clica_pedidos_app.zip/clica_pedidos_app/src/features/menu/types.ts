import { OptionGroupWithOptions } from '@/features/option-groups/types'
import { InsertCategory, SelectCategory } from '@/services/db/schema/categories'
import { InsertItemOffering, SelectItemOffering } from '@/services/db/schema/item-offerings'
import { InsertItem, SelectItem } from '@/services/db/schema/items'
import { SelectStoreFile } from '@/services/db/schema/store-files'

export type BaseStoreFile = Pick<SelectStoreFile, 'id' | 'url'>

export type NewCategory = Omit<PartialBy<InsertCategory, 'index'>, 'id'>

export type BaseCategory = Pick<SelectCategory, 'id' | 'name'> & {
  imageUrl?: string | null
}

export type Category = SelectCategory

export type CategoryWithImage = Omit<SelectCategory, 'imageId'> & {
  image: BaseStoreFile | null
  items?: ItemOfferingWithImage[]
}

export type NewItemOffering = Omit<PartialBy<InsertItemOffering, 'index'>, 'id' | 'itemId'>

export type NewItem = Omit<InsertItem, 'id'> & {
  offerings: NewItemOffering[]
}

export type Item = SelectItem
export type ItemWithImage = Omit<SelectItem, 'imageId'> & {
  image: BaseStoreFile | null
}
export type ItemOfferingWithImage = ItemWithImage &
  Omit<SelectItemOffering, 'id' | 'categoryId' | 'itemId' | 'createdAt' | 'updatedAt'> & {
    itemOfferingId: number
    optionGroups?: OptionGroupWithOptions[]
  }

export type MenuItem = Omit<SelectItemOffering, 'categoryId' | 'createdAt' | 'updatedAt'> &
  Omit<ItemWithImage, 'id' | 'createdAt' | 'updatedAt'> & {
    category: BaseCategory
    optionGroups: OptionGroupWithOptions[]
  }
