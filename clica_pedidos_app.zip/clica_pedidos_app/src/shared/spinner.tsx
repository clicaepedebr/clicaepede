import { cn } from '@/shared/lib/utils'

export interface LoadingSpinnerProps extends React.SVGProps<SVGSVGElement> {
  size?: number
  className?: string
}

export const LoadingSpinner = ({ size = 24, className, ...props }: LoadingSpinnerProps) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      {...props}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={cn('animate-spin text-blue-500', className)}
    >
      <path d="M21 12a9 9 0 1 1-6.219-8.56" />
    </svg>
  )
}

export const PageLoadingSpinner = ({ size = 40, ...props }: LoadingSpinnerProps) => {
  return (
    <div className="w-full h-full flex items-center justify-center">
      <LoadingSpinner size={size} {...props} />
    </div>
  )
}
