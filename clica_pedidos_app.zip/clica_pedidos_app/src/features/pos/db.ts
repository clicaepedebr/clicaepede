'use server'

import { db } from '@/services/db'
import {
  counterSessionsTable,
  countersTable,
  InsertCounter,
  ordersTable,
  SelectCounterSession,
  usersTable,
} from '@/services/db/schema'
import { orderPaymentsTable } from '@/services/db/schema/order-payments'
import { DbSession } from '@/services/db/types'
import { getSubQueryColumns, groupingSets } from '@/services/db/utils'
import {
  formatValueToCurrency,
  getValueFromCurrencyString,
} from '@/shared/formatters/currency'
import {
  and,
  countDistinct,
  desc,
  eq,
  getTableColumns,
  gte,
  isNull,
  lte,
  or,
  sql,
  sum,
} from 'drizzle-orm'
import { UserId } from '../user/types'

const currentCounterSessionSubQuery = db
  .select()
  .from(counterSessionsTable)
  .where(eq(countersTable.id, counterSessionsTable.counterId))
  .orderBy(desc(counterSessionsTable.id))
  .limit(1)
  .as('currentCounterSessionSubQuery')

const listCountersQuery = ({
  storeId,
  counterId,
}: {
  storeId?: number
  counterId?: number
}) =>
  db
    .select({
      ...getTableColumns(countersTable),
      isInService: sql<boolean>`${currentCounterSessionSubQuery.status} = 'OPEN'`,
      currentSession: {
        ...getSubQueryColumns(currentCounterSessionSubQuery),
        operatorName: usersTable.name,
        operatorEmail: usersTable.email,
      },
    })
    .from(countersTable)
    .leftJoinLateral(currentCounterSessionSubQuery, sql`true`)
    .leftJoin(
      usersTable,
      eq(usersTable.id, currentCounterSessionSubQuery.operatorId)
    )
    .where(
      and(
        storeId ? eq(countersTable.storeId, storeId) : undefined,
        counterId ? eq(countersTable.id, counterId) : undefined
      )
    )
    .orderBy(countersTable.id)

export const listStoreCountersOnDb = async ({ storeId }: { storeId: number }) =>
  await listCountersQuery({ storeId })

export const createStoreCounterOnDb = async (newCounter: InsertCounter) =>
  await db.insert(countersTable).values(newCounter)

export const getCounterByIdOnDb = async (counterId: number) => {
  const [counter] = await listCountersQuery({ counterId })
  return counter as typeof counter | undefined
}

export const getCounterSessionByIdOnDb = async (counterSessionId: number) => {
  const [counterSession] = await db
    .select({
      ...getTableColumns(counterSessionsTable),
      counter: {
        ...getTableColumns(countersTable),
      },
    })
    .from(counterSessionsTable)
    .leftJoin(
      countersTable,
      eq(countersTable.id, counterSessionsTable.counterId)
    )
    .where(eq(counterSessionsTable.id, counterSessionId))
    .limit(1)
  return counterSession as typeof counterSession | undefined
}

export const openCounterOnDb = async (props: {
  counterId: number
  operatorId: UserId
  openAmount: string
  openNotes: string | null
}) => {
  const result = await db.insert(counterSessionsTable).values(props).returning()

  return result[0]
}

export const updateOpenCounterReceiptForSessionOnDb = async ({
  counterSessionId,
  receipt,
}: {
  counterSessionId: number
  receipt: string
}) => {
  const result = await db
    .update(counterSessionsTable)
    .set({ openReceipt: receipt })
    .where(eq(counterSessionsTable.id, counterSessionId))
    .returning()

  return result[0]
}

export const closeCounterOnDb = async ({
  counterSessionId,
  dbSession,
  ...props
}: {
  counterSessionId: number
  closedByOperatorId: UserId
  closeAmount: string
  closeNotes: string | null
  dbSession: DbSession
}): Promise<
  NonNullableBy<SelectCounterSession, 'closedAt' | 'closedByOperatorId'>
> => {
  const result = await dbSession
    .update(counterSessionsTable)
    .set({ ...props, status: 'CLOSED', closedAt: sql`CURRENT_TIMESTAMP` })
    .where(eq(counterSessionsTable.id, counterSessionId))
    .returning()

  return result[0]
}

export const updateCloseCounterReceiptForSessionOnDb = async ({
  counterSessionId,
  receipt,
  dbSession,
}: {
  counterSessionId: number
  receipt: string
  dbSession: DbSession
}) => {
  const result = await dbSession
    .update(counterSessionsTable)
    .set({ closeReceipt: receipt })
    .where(eq(counterSessionsTable.id, counterSessionId))
    .returning()

  return result[0]
}

export const calculateCounterSessionSummary = async (
  counterSessionId: number
) => {
  const ordersAndPaymentsTempTable = db.$with('ordersAndPaymentsTempTable').as(
    db
      .select({
        ...getTableColumns(ordersTable),
        paymentValue: orderPaymentsTable.value,
        paymentMethod: orderPaymentsTable.method,
      })
      .from(ordersTable)
      .leftJoin(
        orderPaymentsTable,
        eq(orderPaymentsTable.orderId, ordersTable.id)
      )
      .leftJoin(
        counterSessionsTable,
        eq(counterSessionsTable.id, counterSessionId)
      )
      .where(
        and(
          eq(ordersTable.posCounterId, counterSessionsTable.counterId),
          gte(ordersTable.createdAt, counterSessionsTable.openedAt),
          or(
            isNull(counterSessionsTable.closedAt),
            lte(ordersTable.createdAt, counterSessionsTable.closedAt)
          )
        )
      )
  )

  const { groupingSetsSQL: groupSetsSQL, groupingColumns } = groupingSets({
    paymentMethod: ordersAndPaymentsTempTable.paymentMethod,
    salesChannel: ordersAndPaymentsTempTable.salesChannel,
    type: ordersAndPaymentsTempTable.type,
  })

  const result = await db
    .with(ordersAndPaymentsTempTable)
    .select({
      ...groupingColumns,
      ordersCount: countDistinct(ordersAndPaymentsTempTable.id).as(
        'ordersCount'
      ),
      total: sum(ordersAndPaymentsTempTable.paymentValue).as('total'),
    })
    .from(ordersAndPaymentsTempTable)
    .groupBy(groupSetsSQL)

  type GroupingColumnsKeys = keyof typeof groupingColumns
  type SummaryInfo = Pick<(typeof result)[number], 'ordersCount' | 'total'>
  type GroupingCategory =
    (typeof ordersAndPaymentsTempTable)[GroupingColumnsKeys]['_']['data']

  type SummaryGroupingKey = 'orderType' | Exclude<GroupingColumnsKeys, 'type'>
  type GroupingKeySummaryInfo = Record<GroupingCategory, SummaryInfo>

  const summary = result.reduce(
    (acc, item) => {
      const groupingKey = Object.keys(groupingColumns).find(
        key => item[key as GroupingColumnsKeys] != null
      ) as GroupingColumnsKeys

      const { ordersCount, total } = item
      const groupingCategory = item[groupingKey]!

      const summaryInfo = {
        ordersCount,
        total,
      }
      const summaryGroupingKey =
        groupingKey === 'type' ? 'orderType' : groupingKey
      const groupingKeySummaryInfo = acc[summaryGroupingKey] ?? {}

      acc[summaryGroupingKey] = {
        ...groupingKeySummaryInfo,
        [groupingCategory]: summaryInfo,
      }
      return acc
    },
    {} as Record<SummaryGroupingKey, GroupingKeySummaryInfo>
  )

  const totalSummary = Object.values(summary?.orderType ?? {}).reduce(
    (acc, { total, ordersCount }) => {
      acc.ordersCount += ordersCount
      acc.total += getValueFromCurrencyString(total ?? '0')
      return acc
    },
    {
      ordersCount: 0,
      total: 0,
    }
  )

  return {
    categoriesSummary: summary,
    totalSummary: {
      ordersCount: totalSummary.ordersCount,
      total: formatValueToCurrency({
        value: totalSummary.total,
        decimalPlaces: 4,
      }),
    },
  }
}
