import * as React from 'react'

import { cn } from '@/shared/lib/utils'

type TextAreaProps = React.ComponentProps<'textarea'> & { error?: string }

export const Textarea = ({ className, error, ...props }: TextAreaProps) => {
  return (
    <textarea
      data-slot="textarea"
      className={cn(
        'placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground dark:bg-input/30 border-input flex w-full min-w-0 rounded border bg-transparent px-3 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm',
        'focus-visible:border-ring focus-visible:ring-primary/20 focus-visible:ring-[3px]',
        'aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive',
        className
      )}
      {...props}
      aria-invalid={!!error}
      aria-errormessage={error}
    />
  )
}
