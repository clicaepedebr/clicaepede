import { createOrder, validateCartStock } from '@/features/order/api'
import { SalesChannel } from '@/features/order/types'
import {
  addItemToCartAtom,
  addPaymentAtom,
  amountLeftToPayAtom,
  amountPaidAtom,
  cartSessionItemsAtom,
  cartSessionPaymentsAtom,
  cartSessionTotalAtom,
  clearCartAtom,
  clearStockErrorsAtom,
  hasStockErrorsAtom,
  isUsingPaymentScreenAtom,
  removeItemFromCartAtom,
  resetPaymentsAtom,
  stockValidationErrorsAtom,
  updateCartItemAtom,
  updateItemQuantityAtom,
} from '@/features/pos/state'
import { CartItem, CartPayment } from '@/features/pos/types'
import { selectedStoreIdAtom } from '@/features/store/state'
import { formatValueToCurrency } from '@/shared/formatters/currency'
import { dispatchToast } from '@/shared/lib/toast'
import { useMutation } from '@tanstack/react-query'
import { useAtom } from 'jotai'
import { useCallback, useEffect } from 'react'

type CreateOrderParams = {
  counterId: number
  counterName: string
  items?: CartItem[]
  payments?: CartPayment[]
  totalPrice?: number
  storeId?: number
}

export const useCart = (salesChannel: SalesChannel) => {
  const [selectedStoreId] = useAtom(selectedStoreIdAtom)
  const [cartSessionItems] = useAtom(cartSessionItemsAtom)
  const [cartSessionPayments] = useAtom(cartSessionPaymentsAtom)
  const [cartSessionTotal] = useAtom(cartSessionTotalAtom)
  const [, addItemToCart] = useAtom(addItemToCartAtom)
  const [, clearCart] = useAtom(clearCartAtom)
  const [, removeItemFromCart] = useAtom(removeItemFromCartAtom)
  const [, updateItemQuantity] = useAtom(updateItemQuantityAtom)
  const [, updateCartItem] = useAtom(updateCartItemAtom)
  const [, addPayment] = useAtom(addPaymentAtom)
  const [, resetPayments] = useAtom(resetPaymentsAtom)
  const [isUsingPaymentScreen, setIsUsingPaymentScreen] = useAtom(
    isUsingPaymentScreenAtom
  )
  const [amountPaid] = useAtom(amountPaidAtom)
  const [amountLeftToPay] = useAtom(amountLeftToPayAtom)
  const [stockValidationErrors, setStockValidationErrors] = useAtom(
    stockValidationErrorsAtom
  )
  const [hasStockErrors] = useAtom(hasStockErrorsAtom)
  const [, clearStockErrors] = useAtom(clearStockErrorsAtom)

  useEffect(() => {
    if (!selectedStoreId || !cartSessionItems?.length) return

    const cartItemsIndexesToRemove = cartSessionItems
      .filter(cartItem => cartItem.storeId !== selectedStoreId)
      .map((_, index) => index)
      .reverse()

    cartItemsIndexesToRemove.forEach(index => removeItemFromCart(index))
  }, [selectedStoreId])

  useEffect(() => {
    if (cartSessionItems?.length) return

    if (cartSessionPayments?.length) {
      resetPayments()
    }
    if (isUsingPaymentScreen) {
      setIsUsingPaymentScreen(false)
    }
  }, [cartSessionItems])

  // Clear stock errors when cart items change (user might resolve issues)
  useEffect(() => {
    if (stockValidationErrors.length > 0) {
      clearStockErrors()
    }
  }, [cartSessionItems])

  // Validate stock availability for cart items
  const validateStock = useCallback(async () => {
    if (!selectedStoreId || !cartSessionItems?.length) {
      return true // No items to validate
    }

    const items = cartSessionItems.map(item => ({
      itemId: item.itemId,
      quantity: item.quantity,
    }))

    const outOfStockItems = await validateCartStock({
      storeId: selectedStoreId,
      items,
    })

    setStockValidationErrors(outOfStockItems)
    return outOfStockItems.length === 0
  }, [selectedStoreId, cartSessionItems, setStockValidationErrors])

  const createOrderMutation = useMutation({
    mutationFn: async ({
      counterId,
      counterName,
      items,
      payments,
      totalPrice,
      storeId,
    }: CreateOrderParams) => {
      const effectiveStoreId = storeId ?? selectedStoreId
      const effectiveItems = items ?? cartSessionItems
      const effectivePayments = payments ?? cartSessionPayments
      const effectiveTotal = totalPrice ?? cartSessionTotal

      if (!effectiveStoreId || !effectiveItems?.length || !effectivePayments?.length) {
        return
      }

      const orderItems = effectiveItems.map((cartItem, index) => ({
        index,
        itemId: cartItem.itemId,
        quantity: cartItem.quantity.toString(),
        price: cartItem.price,
        originalPrice: cartItem.originalPrice,
        itemName: cartItem.name,
        categoryName: cartItem.category.name,
        categoryId: cartItem.category.id,
        externalCode: cartItem.externalCode,
        ean: cartItem.ean,
        comment: cartItem.comment ?? null,
        options: (cartItem.selectedOptions ?? []).map((opt, optIndex) => ({
          optionGroupName: opt.optionGroupName,
          optionName: opt.optionName,
          price: formatValueToCurrency({ value: opt.price }),
          quantity: formatValueToCurrency({ value: opt.quantity }),
          index: optIndex,
        })),
      }))

      const orderPayments = effectivePayments.map(payment => ({
        type: payment.type,
        value: payment.value,
        method: payment.method,
        changeFor: payment.changeFor,
        cardBrand: payment.cardBrand,
      }))

      const newOrder = await createOrder({
        storeId: effectiveStoreId!,
        items: orderItems,
        totalPrice: formatValueToCurrency({ value: effectiveTotal }),
        salesChannel: salesChannel,
        type: 'INDOOR',
        status: 'COMPLETED',
        posCounterId: counterId,
        posCounterName: counterName,
        payments: orderPayments,
      })

      return newOrder
    },
    onError: () => {
      dispatchToast({ message: `Erro ao criar pedido`, type: 'error' })
    },
    onSuccess: newOrder => {
      if (newOrder?.displayId) {
        dispatchToast({
          message: `Pedido '#${newOrder.displayId}' criado com sucesso`,
          type: 'success',
        })
      }
      clearCart()
    },
  })

  return {
    cartSessionItems,
    cartSessionTotal,
    cartSessionPayments,
    addItemToCart,
    clearCart,
    removeItemFromCart,
    updateItemQuantity,
    updateCartItem,
    addPayment,
    createOrder: createOrderMutation.mutateAsync,
    isUsingPaymentScreen,
    setIsUsingPaymentScreen,
    amountPaid,
    amountLeftToPay,
    // Stock validation
    validateStock,
    stockValidationErrors,
    hasStockErrors,
    clearStockErrors,
  }
}
