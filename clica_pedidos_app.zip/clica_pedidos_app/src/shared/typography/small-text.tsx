import { cn } from '@/shared/lib/utils'

export const SmallText = ({ children, className }: { children: React.ReactNode; className?: string }) => {
  return <small className={cn('text-sm font-medium leading-none', className)}>{children}</small>
}
